#include <librpi/debug.h>          // For debug_print

void Externc__g_step(int* i, int*o) {
  *o = *i + 5 ;
  debug_printf("G(%d) = %d.\n",*i,*o) ;
}

void Externc__f_step(int* i, int*o) {
  *o = *i + 1 ;
  debug_printf("F(%d) = %d.\n",*i,*o) ;
}
