#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/ioctl.h>

#define DO_THING _IOW(0xFE, 1, int)
#define DO_MORE _IOR(0xFE, 2, int)

struct buffer {
	unsigned char *buf;
	size_t size;
};

int main(void)
{
	int fd;

	fd = open("/dev/chip", O_RDWR);
	if (fd < 0) {
		printf("there is a problem\n");
		return 1;
	}

	struct buffer buffer_to_chip = { "testtest", 8 };
	char buffer_from_chip[25];

	ioctl(fd, DO_THING, &buffer_to_chip);

	ioctl(fd, DO_MORE, &buffer_from_chip);

	printf("I send %s\n", buffer_to_chip.buf);
	printf("I receive %s\n", buffer_from_chip);

	close(fd);
	return 0;
}
