#include <linux/mutex.h>
#include <linux/gpio/driver.h>
#include <linux/gpio/consumer.h>
#include <linux/cdev.h>
#include <linux/errno.h>
#include <linux/fs.h>
#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/slab.h>
#include <linux/uaccess.h>
#include <linux/ioctl.h>
#include <linux/spi/spi.h>
#include <linux/mod_devicetable.h>
#include <linux/of_device.h>
#include <linux/ioctl.h>

#define DEVICE_NAME "chip"
#define CLASS_NAME "chip_class"
#define CHIP_IOCTL_IN _IOW(0xFE, 1, int)
#define CHIP_IOCTL_OUT _IOR(0xFE, 2, int)

MODULE_AUTHOR("Groupe 9");
MODULE_LICENSE("GPL");
MODULE_DESCRIPTION("Driver pour le chip MFRC522");

struct buffer {
	unsigned char *buf;
	size_t size;
};

static int major;
static struct class *chipcharclass;
static struct device *chipchardevice;
static struct spi_device *spidevice;

/* Char device file operations */
int chip_open(struct inode *inode, struct file *filp)
{
	return 0;
}
ssize_t chip_read(struct file *filp, char __user *buf, size_t len, loff_t *off)
{
	return 0;
}
int chip_release(struct inode *inode, struct file *filp)
{
	return 0;
}
ssize_t chip_write(struct file *filp, const char __user *buf, size_t len,
	loff_t *off)
{
	return 0;
}

static unsigned char read_msg(unsigned char addr)
{
	int ret;
	unsigned char regaddr;
	unsigned char res = 0;

	regaddr = ((addr<<1) & 0x7E) | 0x80;
	ret = spi_write_then_read(spidevice, &regaddr, 1, &res, 1);
	if (ret != 0)
		pr_err("spi_write_then_read error\n");
	return res;
}

static void write_msg(unsigned char addr, unsigned char data)
{
	unsigned char regaddr;
	struct spi_transfer st[2];
	struct spi_message msg;

	spi_message_init(&msg);
	memset(st, 0, sizeof(st));

	regaddr = ((addr<<1) & 0x7E);
	st[0].tx_buf = &regaddr;
	st[0].len = 1;
	spi_message_add_tail(&st[0], &msg);

	st[1].tx_buf = &data;
	st[1].len = 1;
	spi_message_add_tail(&st[1], &msg);

	spi_sync(spidevice, &msg);
}

void set_bit_mask(unsigned char reg, unsigned char mask)
{
	char tmp = 0x0;

	tmp = read_msg(reg);
	write_msg(reg, tmp | mask);
}

void clear_bit_mask(unsigned char reg, unsigned char mask)
{
	char tmp = 0x0;

	tmp = read_msg(reg);
	write_msg(reg, tmp & ~mask);
}

static void user_to_chip(struct buffer *buffer)
{
	int i;

	// state idle
	write_msg(0x01, 0x00);

	// clear fifo
	set_bit_mask(0x0A, 0x80);
	clear_bit_mask(0x0A, 0x80);

	// put user buffer in chip buffer
	for (i = 0; i < buffer->size; i++)
		write_msg(0x09, buffer->buf[i]);

	// fill with 0 if necessary
	for (i = buffer->size; i < 25; i++)
		write_msg(0x09, '\0');

	// state mem
	write_msg(0x01, 0x01);
}

static void chip_to_user(char *buffer)
{
	int i;
	int fifo_size;
	int ret;
	unsigned char tmp[25];

	// state idle
	write_msg(0x01, 0x00);

	// clear fifo
	set_bit_mask(0x0A, 0x80);
	clear_bit_mask(0x0A, 0x80);

	// state mem
	write_msg(0x01, 0x01);

	// size of fifo
	fifo_size = read_msg(0x0A);

	// read bytes in fifo and put it in user buffer
	for (i = 0; i < fifo_size; i++)
		tmp[i] = read_msg(0x09);
	ret = copy_to_user(buffer, tmp, fifo_size);
}

long ioctl_functions(struct file *filp, unsigned int cmd, unsigned long arg)
{
	switch (cmd) {
	case CHIP_IOCTL_IN:
		pr_info("chip ioctl in\n");
		user_to_chip((struct buffer *)arg);
		break;
	case CHIP_IOCTL_OUT:
		pr_info("chip ioctl out\n");
		chip_to_user((char *)arg);
		break;
	default:
		pr_info("none\n");
	}
	return 0;
}

static const struct file_operations chip_fops = {
	.owner = THIS_MODULE,
	.open = chip_open,
	.read = chip_read,
	.write = chip_write,
	.release = chip_release,
	.unlocked_ioctl = ioctl_functions
};

/* Init and exit */
__init
static int chip_init(void)
{
	// allocate major
	major = register_chrdev(0, DEVICE_NAME, &chip_fops);
	if (major < 0) {
		pr_err("Failed to allocate major\n");
		return major;
	}

	// register device class
	chipcharclass = class_create(THIS_MODULE, CLASS_NAME);
	if (IS_ERR(chipcharclass)) {
		unregister_chrdev(major, DEVICE_NAME);
		pr_err("Failed to register device class\n");
		return PTR_ERR(chipcharclass);
	}

	// register device driver
	chipchardevice = device_create(chipcharclass, NULL, MKDEV(major, 0),
		NULL, DEVICE_NAME);
	if (IS_ERR(chipchardevice)) {
		class_destroy(chipcharclass);
		unregister_chrdev(major, DEVICE_NAME);
		pr_err("Failed to create the device\n");
		return PTR_ERR(chipchardevice);
	}

	pr_info("Hello, card reader!\n");
	return 0;
}

__exit
static void chip_exit(void)
{
	device_destroy(chipcharclass, MKDEV(major, 0));
	class_destroy(chipcharclass);
	unregister_chrdev(major, DEVICE_NAME);
}

/* probe and remove */
int chip_probe(struct spi_device *spi_dev)
{
	pr_info("probe\n");
	spidevice = spi_dev;
	chip_init();
	return 0;
}

int chip_remove(struct spi_device *spi_dev)
{
	pr_info("remove\n");
	chip_exit();
	return 0;
}

static const struct of_device_id chip_id[] = {
	{.compatible = "nxp.mfrc522"},
	{}
};
MODULE_DEVICE_TABLE(of, chip_id);

static struct spi_driver chip_driver = {
	.driver = {
		.name = "chip_driver",
		.owner = THIS_MODULE,
		.of_match_table = chip_id
	},
	.probe = chip_probe,
	.remove = chip_remove
};

module_spi_driver(chip_driver);
